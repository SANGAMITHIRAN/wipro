package com.example.wipro.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "Address")
public class Address {
	
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "addressId")
	private long addressId;

	@Column(name = "streetname")
	private String streetname;

	@Column(name = "pincode")
	private String pincode;




	
	
	public long getAddressId() {
		return addressId;
	}






	public void setAddressId(long addressId) {
		this.addressId = addressId;
	}






	public String getStreetname() {
		return streetname;
	}






	public void setStreetname(String streetname) {
		this.streetname = streetname;
	}






	public String getPincode() {
		return pincode;
	}






	public void setPincode(String pincode) {
		this.pincode = pincode;
	}






	public PersonEntity getPersonEntity() {
		return personEntity;
	}






	public void setPersonEntity(PersonEntity personEntity) {
		this.personEntity = personEntity;
	}






	@ManyToOne
	@JoinColumn(name = "id")
	private PersonEntity personEntity;
	

	

	
}
