package com.example.wipro.entity;

 

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

/**
 * @author user
 *
 */
@Entity
@Table(name = "personEntity")
public class PersonEntity{

	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "id")
	private long personId;
	
	
	/*@EmbeddedId
	@Column(name="primarySample")
	private PrimarySample primarySample;*/

	@Column(name = "name")
	private String name;

	@Column(name = "height")
	private int height;

	@Column(name = "condition")
	private boolean condition;
	
	@OneToMany(mappedBy="personEntity",cascade=CascadeType.ALL)
	private List<Address> address;

	public long getPersonId() {
		return personId;
	}

	public void setPersonId(long personId) {
		this.personId = personId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getHeight() {
		return height;
	}

	public void setHeight(int height) {
		this.height = height;
	}

	public boolean isCondition() {
		return condition;
	}

	public void setCondition(boolean condition) {
		this.condition = condition;
	}

	public List<Address> getAddress() {
		return address;
	}

	public void setAddress(List<Address> address) {
		this.address = address;
	}

	

	
	

	

	

	

	
	
}
