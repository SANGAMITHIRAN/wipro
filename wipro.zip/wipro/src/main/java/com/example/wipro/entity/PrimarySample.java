package com.example.wipro.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import org.checkerframework.checker.interning.qual.UsesObjectEquals;

import lombok.EqualsAndHashCode;

@Embeddable
@EqualsAndHashCode
public class PrimarySample implements Serializable{
	
	
	
	@Column(name = "sampleEntityID")
	private String sampleEntityID;
	
	@Column(name = "secondsampleId")
	private String secondsampleId;

	public String getSampleEntityID() {
		return sampleEntityID;
	}

	public void setSampleEntityID(String sampleEntityID) {
		this.sampleEntityID = sampleEntityID;
	}

	public String getSecondsampleId() {
		return secondsampleId;
	}

	public void setSecondsampleId(String secondsampleId) {
		this.secondsampleId = secondsampleId;
	}
	
	
	
}
