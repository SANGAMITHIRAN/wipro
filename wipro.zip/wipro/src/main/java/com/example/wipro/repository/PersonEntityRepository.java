package com.example.wipro.repository;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.example.wipro.entity.PersonEntity;

@Repository
public interface PersonEntityRepository extends JpaRepository<PersonEntity, Long>{

               

	PersonEntity findByName(String name);
	
	
	/*@Query("select * from ")
	PersonEntity findByHeight(long height);*/

 

}