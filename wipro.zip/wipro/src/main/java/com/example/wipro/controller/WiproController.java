
package com.example.wipro.controller;

 

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.function.Function;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.util.CollectionUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.wipro.dto.AddressDTO;
import com.example.wipro.dto.PersonDTO;
import com.example.wipro.entity.Address;
import com.example.wipro.entity.PersonEntity;
import com.example.wipro.repository.PersonEntityRepository;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;

@RestController
@RequestMapping("/wiprocontroller")
public class WiproController {
	@Autowired
	private PersonEntityRepository personEntityRepository;

	@PostMapping("/add")
	public ResponseEntity<String> addvalues(@RequestBody(required = true) String requestBody) {
		try {
			 
			 
			ObjectMapper obj = new ObjectMapper();
			obj.enable(DeserializationFeature.ACCEPT_SINGLE_VALUE_AS_ARRAY);
			List<PersonDTO> personEntityDTOLists = obj.readValue(requestBody, new TypeReference<List<PersonDTO>>() {
			});
			
			//PersonDTO link = obj.readValue(requestBody, PersonDTO.class);
			List<PersonEntity> personEntityList = new ArrayList<>();
			if (!CollectionUtils.isEmpty(personEntityDTOLists)) {
				personEntityDTOLists.stream().forEach(e -> {
					PersonEntity personEntity = new PersonEntity();
					personEntity.setCondition(e.isCondition());
					personEntity.setHeight(e.getHeight());
					personEntity.setName(e.getName());
					
					
					List<AddressDTO> addressDTOList=e.getAddressDTO();
					List<Address> addressList=new ArrayList<>();
					
						addressDTOList.stream().forEach(i->{
						Address address=new Address();
						address.setPersonEntity(personEntity);
						address.setPincode(i.getPincode());
						address.setStreetname(i.getStreetname());
						addressList.add(address);
					});
						personEntity.setAddress(addressList);
						personEntityList.add(personEntity);
				});
				personEntityRepository.saveAll(personEntityList);
			}
		} catch (Exception e) {
			return new ResponseEntity<String>("addvalues Failed", HttpStatus.BAD_REQUEST);
		}
		return new ResponseEntity<String>(" Values Created Successfully", HttpStatus.CREATED);
	}
	
	
	@PutMapping("/update")
	public ResponseEntity<String> updateValues(@RequestBody(required = true) String requestBody) {
		try {
			ObjectMapper obj = new ObjectMapper();
			obj.enable(DeserializationFeature.ACCEPT_SINGLE_VALUE_AS_ARRAY);
			PersonDTO personDTO = obj.readValue(requestBody, PersonDTO.class);
			Optional<PersonEntity> personEntityOptional = personEntityRepository.findById(personDTO.getPersonId());
			//PersonDTO link = obj.readValue(requestBody, PersonDTO.class);
			if (personEntityOptional.isPresent()) {
				PersonEntity personEntity=personEntityOptional.get();
				personEntity.setCondition(personDTO.isCondition());
				personEntity.setHeight(personDTO.getHeight());
				personEntity.setName(personDTO.getName());
				
				
				List<AddressDTO> addressDTOList=personDTO.getAddressDTO();
				List<Address> addressList=new ArrayList<>();
				
					addressDTOList.stream().forEach(i->{
					Address address=new Address();
					address.setPersonEntity(personEntity);
					address.setPincode(i.getPincode());
					address.setStreetname(i.getStreetname());
					addressList.add(address);
				});
					personEntity.setAddress(addressList);
					personEntityRepository.save(personEntity);
			}
			
				
		} catch (Exception e) {
			return new ResponseEntity<String>("addvalues Failed", HttpStatus.BAD_REQUEST);
		}
		return new ResponseEntity<String>(" Values Created Successfully", HttpStatus.CREATED);
	}
	
	@GetMapping("/all")
	public ResponseEntity<List<PersonEntity>> getAll() {
		try {
			List<PersonEntity> sampleEntity =  personEntityRepository.findAll();
				return new ResponseEntity<List<PersonEntity>>(sampleEntity, HttpStatus.OK);
		} catch (Exception e) {
			return new ResponseEntity<List<PersonEntity>>(HttpStatus.BAD_REQUEST);
		}
	}
	
	

	@GetMapping("/id")
	public ResponseEntity<PersonEntity> getvalues(@RequestParam(value = "personId", required = false) Long personId,@RequestParam(value = "name", required = false) String name) {
		try {
			
			if(personId!=null) {
			Optional<PersonEntity> personEntity = personEntityRepository.findById(personId);
			if (personEntity.isPresent()) {
				return new ResponseEntity<PersonEntity>(personEntity.get(), HttpStatus.OK);
			} else {
				return new ResponseEntity<PersonEntity>(HttpStatus.NO_CONTENT);
			}
			}else {
				PersonEntity personEntity=personEntityRepository.findByName(name);
				return new ResponseEntity<PersonEntity>(personEntity, HttpStatus.OK);
			}
		} catch (Exception e) {
			return new ResponseEntity<PersonEntity>(HttpStatus.BAD_REQUEST);
		}
	}

	@GetMapping("/validateLargestNumber")
	public ResponseEntity<String> validateLargestNumber(@RequestBody(required = true) String requestBody) {
		Integer sampleId = null;
		try {
			ObjectMapper obj = new ObjectMapper();
			obj.enable(DeserializationFeature.ACCEPT_SINGLE_VALUE_AS_ARRAY);
			List<PersonDTO> sampleDTOLists = obj.readValue(requestBody, new TypeReference<List<PersonDTO>>() {
			});
			Optional<PersonDTO> ss = null;
			if (!CollectionUtils.isEmpty(sampleDTOLists)) {
				ss = sampleDTOLists.stream().max(Comparator.comparing(PersonDTO::getHeight));
				if (ss.isPresent()) {
					sampleId = ss.get().getHeight();
				}
			}
		} catch (Exception e) {
			return new ResponseEntity<String>("validateLargestNumber Failed", HttpStatus.BAD_REQUEST);
		}
		return new ResponseEntity<String>(sampleId.toString(), HttpStatus.OK);
	}

	@GetMapping("/findDuplicates")
	public ResponseEntity<String> findDuplicates(@RequestBody(required = true) String requestBody) {
		Set<String> listOfNames = null;
		try {
			ObjectMapper obj = new ObjectMapper();
			obj.enable(DeserializationFeature.ACCEPT_SINGLE_VALUE_AS_ARRAY);
			List<PersonDTO> sampleDTOLists = obj.readValue(requestBody, new TypeReference<List<PersonDTO>>() {
			});
			if (!CollectionUtils.isEmpty(sampleDTOLists)) {
				List<String> sampleNames = sampleDTOLists.stream().map(PersonDTO::getName).collect(Collectors.toList());
				listOfNames = sampleNames.stream()
						.collect(Collectors.groupingBy(Function.identity(), Collectors.counting())).entrySet().stream()
						.filter(m -> m.getValue() > 1).map(Map.Entry::getKey).collect(Collectors.toSet());
			} else {
				return new ResponseEntity<String>(HttpStatus.NO_CONTENT);
			}
		} catch (Exception e) {
			return new ResponseEntity<String>("findDuplicates Failed", HttpStatus.BAD_REQUEST);
		}
		return new ResponseEntity<String>(listOfNames.toString(), HttpStatus.OK);
	}

	@GetMapping("/removewhitespaces")
	public ResponseEntity<List<PersonDTO>> removewhitespaces(@RequestBody(required = true) String requestBody) {
		CopyOnWriteArrayList<PersonDTO> sampleDTOLists = null;
		try {
			ObjectMapper obj = new ObjectMapper();
			obj.enable(DeserializationFeature.ACCEPT_SINGLE_VALUE_AS_ARRAY);
			sampleDTOLists = obj.readValue(requestBody, new TypeReference<CopyOnWriteArrayList<PersonDTO>>() {
			});
			if (!CollectionUtils.isEmpty(sampleDTOLists)) {
				sampleDTOLists.stream().forEach(e -> {
					char[] strArray = e.getName().toCharArray();
					StringBuffer stringBuffer = new StringBuffer();
					for (int i = 0; i < strArray.length; i++) {
						if ((strArray[i] != ' ') && (strArray[i] != '\t')) {
							stringBuffer.append(strArray[i]);
						}
					}
					String noSpaceStr2 = stringBuffer.toString();
					e.setName(noSpaceStr2);
				});
			} else {
				return new ResponseEntity<List<PersonDTO>>(HttpStatus.NO_CONTENT);
			}
		} catch (Exception e) {
			return new ResponseEntity<List<PersonDTO>>(HttpStatus.BAD_REQUEST);
		}
		return new ResponseEntity<List<PersonDTO>>(sampleDTOLists, HttpStatus.OK);
	}}
