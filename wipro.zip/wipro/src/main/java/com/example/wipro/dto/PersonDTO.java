package com.example.wipro.dto;

 

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

 

@JsonIgnoreProperties(ignoreUnknown = true)
public class PersonDTO {
	
private long personId;
	private String name;

	private int height;

	private boolean condition;

	private List<AddressDTO> addressDTO;
	
	

	public long getPersonId() {
		return personId;
	}

	public void setPersonId(long personId) {
		this.personId = personId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getHeight() {
		return height;
	}

	public void setHeight(int height) {
		this.height = height;
	}

	public boolean isCondition() {
		return condition;
	}

	public void setCondition(boolean condition) {
		this.condition = condition;
	}

	public List<AddressDTO> getAddressDTO() {
		return addressDTO;
	}

	public void setAddressDTO(List<AddressDTO> addressDTO) {
		this.addressDTO = addressDTO;
	}
	
	
	

}
