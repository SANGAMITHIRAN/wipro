package com.example.wipro;

import java.util.ArrayList;
import java.util.List;

import com.example.wipro.dto.AddressDTO;
import com.example.wipro.dto.PersonDTO;
import com.google.gson.Gson;

public class Testthree {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		
		
		PersonDTO sampleDTO=new PersonDTO();
		
		sampleDTO.setName("sanga");
		
		List<AddressDTO> addressDTOList=new ArrayList<>();
		AddressDTO addressDTO=new AddressDTO();
		addressDTO.setStreetname("dadaad");
		addressDTOList.add(addressDTO);
		sampleDTO.setAddressDTO(addressDTOList);
		
		Gson gson = new Gson();
		String json = gson.toJson(sampleDTO);
		
		System.out.println(json);
	}
}
